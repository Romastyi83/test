
const header = document.querySelector('[data-header]');
const headerInner = document.querySelector('[data-header-inner]');
window.addEventListener('scroll', function () {
  if (window.scrollY > 80) {
    header.classList.add("header--scroll");
    headerInner.classList.add("header__inner--scroll");
  } else {
    header.classList.remove("header--scroll");
    headerInner.classList.remove("header__inner--scroll");
  }
});


const range = document.querySelector('[data-range]');
const rangeValue = document.querySelector('[data-range-value]');

range.addEventListener('input', function () {
  rangeValue.innerText = this.value;
});


const burger = document.querySelector('[data-burger]');
const nav = document.querySelector('[data-nav]');

burger.addEventListener("click", (e) => {
  e.preventDefault();
  burger.classList.toggle('burger__active');
  nav.classList.toggle('nav__active');
  if (burger.classList.contains('burger__active')) {
    document.body.style.overflow = 'hidden';
  } else {
    document.body.style.overflow = '';
  }
});

const select = document.querySelector('[data-select]');

const choices = new Choices(select, {
  searchEnabled: false,
  itemSelectText: ''
});

const choicesHolder = document.querySelector('.choices[data-type*=select-one]');
choicesHolder.addEventListener('click', () => {
  if (choicesHolder.classList.contains('is-open')) {
    select.classList.add('active')
  }
})

